
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';
import { ArrowRight, CheckCircle2, TrendingUp, Users, Award, BookOpen, BadgeCheck, Lightbulb, Building2, Calculator, Target, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRoleFilter } from '@/hooks/useRoleFilter';
import { Dialog, DialogContent, DialogTrigger, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import LeaseVsBuyCalculator from './LeaseVsBuyCalculator';
import SkillsAssessmentGapTest from './SkillsAssessmentGapTest';

const HomePage = () => {
  const navigate = useNavigate();
  const { role: currentRole, setRole } = useRoleFilter();
  const [activeTool, setActiveTool] = useState(null); // 'calculator' | 'assessment' | null

  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const handleRoleSelect = (roleId) => {
    setRole(roleId);
    navigate(`/role/${roleId}`);
  };

  return (
     <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-blue-500 selection:text-white">

      {/* ─── HERO SECTION ─────────────────────────────────────────────── */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20 pb-12">

        {/* Background Image with Gradient Overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1697638164340-6c5fc558bdf2"
            alt="Modern office building"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950/90 via-slate-900/80 to-slate-950" />
          {/* Decorative glows */}
          <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] bg-blue-600/20 rounded-full blur-[100px]" />
          <div className="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] bg-indigo-600/10 rounded-full blur-[120px]" />
        </div>

        {/* Hero Content */}
        <div className="container relative z-10 px-4 mx-auto text-center">
          <motion.div
            initial="hidden"
            animate="visible"
            variants={fadeIn}
            className="max-w-5xl mx-auto space-y-6"
          >

            {/* ── Badge ── */}
            <div className="inline-block mb-2 px-4 py-1.5 my-5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-sm font-semibold tracking-wide uppercase backdrop-blur-sm">
              The Future of Equipment Leasing
            </div>

            {/* ── H1 — clear, audience-specific value prop ── */}
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight leading-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-blue-100 to-slate-400">
              Master Equipment Leasing
            </h1>

            {/* ── Benefit bullets ── */}
            <motion.div
              variants={staggerContainer}
              initial="hidden"
              animate="visible"
              className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-8 pt-2"
            >
              {[
                { icon: BookOpen,    label: 'Self-paced courses'              },
                { icon: BadgeCheck,  label: 'Industry-recognised credentials' },
                { icon: Lightbulb,   label: 'Expert-led content'              },
              ].map((benefit, i) => (
                <motion.div
                  key={i}
                  variants={fadeIn}
                  className="flex items-center gap-2 text-slate-300 text-base font-medium"
                >
                  <benefit.icon className="w-5 h-5 text-blue-400 shrink-0" />
                  <span>{benefit.label}</span>
                </motion.div>
              ))}
            </motion.div>

            {/* ── Primary + Secondary CTAs ── */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              {/* Primary */}
              <Link to="/courses">
                <Button
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg rounded-full shadow-lg shadow-blue-900/20 hover:shadow-blue-900/40 transition-all duration-300 w-full sm:w-auto"
                >
                  Browse Courses
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>

              {/* Secondary */}
              <Link to="/about-us">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-slate-600 text-slate-200 hover:text-white hover:bg-blue-500 hover:border-blue-500/50 px-8 py-6 text-lg rounded-full transition-all duration-300 w-full sm:w-auto bg-transparent"
                >
                  Learn How It Works
                </Button>
              </Link>
            </div>

            {/* ── Trust signal ── */}
            <motion.p
              variants={fadeIn}
              className="text-slate-500 text-sm pt-2"
            >
              Trusted by 500+ leasing and finance professionals
            </motion.p>

            {/* ── Role selection cards ── */}
            <motion.div
              variants={staggerContainer}
              initial="hidden"
              animate="visible"
              className="pt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto"
            >
              {[
                { id: "financier",      icon: TrendingUp, text: "I'm a Financier",               color: "text-blue-400",   bg: "bg-blue-500/10" },
                { id: "sales",          icon: Users,      text: "I'm in Sales",                   color: "text-indigo-400", bg: "bg-indigo-500/10" },
                { id: "business_owner", icon: Award,      text: "I'm a Business Owner",           color: "text-violet-400", bg: "bg-violet-500/10" },
                { id: "vendor",         icon: Award,      text: "I'm a Vendor",                   color: "text-green-400",  bg: "bg-green-500/10" },
                { id: "tax_accountant", icon: Award,      text: "I'm a Tax Accountant",           color: "text-orange-400", bg: "bg-orange-500/10" },
                { id: "lessor",         icon: Building2,  text: "I'm a Leasing Company (Lessor)", color: "text-teal-400",   bg: "bg-teal-500/10" },
              ].map((item, index) => {
                const isSelected = currentRole === item.id;
                return (
                  <div 
                    key={index} 
                    onClick={() => handleRoleSelect(item.id)}
                    className="group"
                  >
                    <motion.div
                      variants={fadeIn}
                      whileHover={{ y: -5 }}
                      className={`bg-slate-800/40 backdrop-blur-md border p-8 rounded-2xl transition-all duration-300 cursor-pointer h-full flex flex-col items-center justify-center gap-4 shadow-lg group-hover:shadow-2xl ${
                        isSelected 
                          ? 'border-blue-500 bg-slate-800/80 shadow-blue-900/20' 
                          : 'border-slate-700/50 hover:bg-slate-800/60 hover:border-blue-500/30'
                      }`}
                    >
                      <div className={`p-4 rounded-full ${item.bg} group-hover:scale-110 transition-transform duration-300 ${isSelected ? 'scale-110 ring-2 ring-blue-500/50 ring-offset-2 ring-offset-slate-900' : ''}`}>
                        <item.icon className={`w-8 h-8 ${item.color}`} />
                      </div>
                      <span className={`font-semibold text-lg text-center transition-colors ${isSelected ? 'text-white' : 'text-slate-200 group-hover:text-white'}`}>
                        {item.text}
                      </span>
                    </motion.div>
                  </div>
                );
              })}
            </motion.div>

          </motion.div>
        </div>
      </section>
      {/* ─── END HERO ─────────────────────────────────────────────────── */}

      {/* ─── INTERACTIVE TOOLS SECTION ────────────────────────────────── */}
      <section className="py-20 bg-slate-950 relative z-20 border-t border-slate-800/50">
        <div className="container px-4 mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Free Industry Tools</h2>
            <p className="text-slate-400 max-w-2xl mx-auto text-lg">
              Evaluate your options and test your knowledge with our interactive calculators and assessments.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* Calculator Card */}
            <Dialog>
              <DialogTrigger asChild>
                <motion.div
                  whileHover={{ y: -5 }}
                  className="glass-panel p-8 rounded-2xl cursor-pointer group hover:border-blue-500/50 transition-all duration-300"
                >
                  <div className="w-14 h-14 bg-blue-500/10 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 border border-blue-500/20">
                    <Calculator className="w-7 h-7 text-blue-400" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-blue-400 transition-colors">Lease vs. Buy Calculator</h3>
                  <p className="text-slate-400 leading-relaxed mb-6">
                    Compare the true cost of leasing versus buying equipment. Calculate NPV, tax shields, and get a clear financial recommendation.
                  </p>
                  <div className="flex items-center text-blue-400 font-medium group-hover:translate-x-2 transition-transform">
                    Open Calculator <ArrowRight className="w-4 h-4 ml-2" />
                  </div>
                </motion.div>
              </DialogTrigger>
              <DialogContent className="max-w-5xl bg-slate-950 border-slate-800 text-slate-100 p-0 overflow-hidden">
                <DialogTitle className="sr-only">Lease vs Buy Calculator</DialogTitle>
                <DialogDescription className="sr-only">Calculate the financial difference between leasing and buying equipment.</DialogDescription>
                <div className="p-6 md:p-8 max-h-[90vh] overflow-y-auto custom-scrollbar">
                  <div className="mb-8">
                    <h2 className="text-3xl font-bold text-white mb-2">Lease vs. Buy Calculator</h2>
                    <p className="text-slate-400">Enter your parameters below to compare the Net Present Value of both options.</p>
                  </div>
                  <LeaseVsBuyCalculator />
                </div>
              </DialogContent>
            </Dialog>

            {/* Assessment Card */}
            <Dialog>
              <DialogTrigger asChild>
                <motion.div
                  whileHover={{ y: -5 }}
                  className="glass-panel p-8 rounded-2xl cursor-pointer group hover:border-indigo-500/50 transition-all duration-300"
                >
                  <div className="w-14 h-14 bg-indigo-500/10 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 border border-indigo-500/20">
                    <Target className="w-7 h-7 text-indigo-400" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-indigo-400 transition-colors">Skills Gap Assessment</h3>
                  <p className="text-slate-400 leading-relaxed mb-6">
                    Test your knowledge across different leasing roles. Identify your skill gaps and get personalized course recommendations.
                  </p>
                  <div className="flex items-center text-indigo-400 font-medium group-hover:translate-x-2 transition-transform">
                    Start Assessment <ArrowRight className="w-4 h-4 ml-2" />
                  </div>
                </motion.div>
              </DialogTrigger>
              <DialogContent className="max-w-4xl bg-slate-950 border-slate-800 text-slate-100 p-0 overflow-hidden">
                <DialogTitle className="sr-only">Skills Gap Assessment</DialogTitle>
                <DialogDescription className="sr-only">Test your knowledge and find skill gaps.</DialogDescription>
                <div className="p-6 md:p-10 max-h-[90vh] overflow-y-auto custom-scrollbar">
                  <SkillsAssessmentGapTest />
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </section>
      {/* ─── END INTERACTIVE TOOLS ────────────────────────────────────── */}

      {/* Features Section */}
      <section className="py-24 bg-slate-900 relative">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5" />
        <div className="container px-4 mx-auto relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
            className="text-center mb-20"
          >
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Why Choose Our Platform?</h2>
            <p className="text-slate-400 max-w-2xl mx-auto text-lg">
              We provide industry-leading education tailored to your specific role in the equipment leasing ecosystem.
            </p>
          </motion.div>

          <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            {[
              {
                title: "Expert-Led Courses",
                description: "Learn from industry veterans with decades of experience in equipment finance and leasing.",
                icon: Award,
                color: "text-amber-400",
                bg: "bg-amber-500/10"
              },
              {
                title: "Role-Based Learning",
                description: "Curriculum specifically designed for Financiers, Sales Professionals, and Customers.",
                icon: Users,
                color: "text-blue-400",
                bg: "bg-blue-500/10"
              },
              {
                title: "Practical Application",
                description: "Real-world case studies and interactive tools to apply what you learn immediately.",
                icon: CheckCircle2,
                color: "text-emerald-400",
                bg: "bg-emerald-500/10"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                variants={fadeIn}
                whileHover={{ y: -10 }}
                className="p-8 rounded-2xl bg-slate-800/50 border border-slate-700 hover:border-blue-500/30 hover:bg-slate-800 transition-all duration-300 shadow-xl hover:shadow-2xl group"
              >
                <div className={`w-14 h-14 ${feature.bg} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon className={`w-7 h-7 ${feature.color}`} />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-blue-400 transition-colors">{feature.title}</h3>
                <p className="text-slate-400 leading-relaxed text-lg">{feature.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900 to-slate-900" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl -mr-20 -mt-20" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl -ml-20 -mb-20" />

        <div className="container px-4 mx-auto text-center relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-8 text-white tracking-tight">Ready to advance your career?</h2>
            <p className="text-blue-100 mb-10 text-xl leading-relaxed">
              Join thousands of professionals mastering the art of equipment leasing today.
            </p>
            <Link to="/signup">
              <Button
                size="lg"
                className="bg-white text-blue-900 hover:bg-blue-50 px-10 py-7 text-lg font-bold rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105"
              >
                Get Started Now
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

    </div>
  );
};

export default HomePage;
